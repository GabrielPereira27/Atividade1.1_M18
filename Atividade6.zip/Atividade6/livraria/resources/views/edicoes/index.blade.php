<ul>
@foreach($edicoes as $edicao)
<li>
	<a href="{{route('edicoes.show' , ['id' => $edicoes ->id_editora])}}">
	{{$edicao->id_editora}}</li>
@endforeach
</ul>
{{$edicoes->render()}}