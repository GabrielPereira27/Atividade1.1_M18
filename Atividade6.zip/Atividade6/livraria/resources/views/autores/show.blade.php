ID:{{$autores->id_autor}}<br>
Nome:{{$autores->nome}}<br>
Nacionalidade:{{$autores->nacionalidade}}<br>

@foreach ($autores->livros as $livro)
<h3>{{$livro->titulo}}</h3>
@endforeach