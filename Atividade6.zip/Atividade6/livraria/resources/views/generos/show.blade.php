@foreach ($genero->livros as $livro)
<h3>{{$livro->titulo}}</h3>
@endforeach
