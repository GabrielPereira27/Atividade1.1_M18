ID:{{$editoras->ide}}<br>
Título:{{$editoras->nome}}<br>
Idioma:{{$editoras->morada}}