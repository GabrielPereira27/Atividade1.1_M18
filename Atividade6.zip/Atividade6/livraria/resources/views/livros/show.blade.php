<b>ID:{{$livro->idl}}</b><br>
<b>Título:{{$livro->titulo}}</b><br>
<b>Idioma:{{$livro->idioma}}</b><br>
@if(isset($livro->genero->designacao))
<b>{{$livro->genero->designacao}}</b>
@endif