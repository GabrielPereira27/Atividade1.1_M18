@if(isset($livro->genero->designacao))
{{$livro->genero->designacao}}
@endif