ID:<?php echo e($generos->idg); ?><br>
Designacao:<?php echo e($generos->designacao); ?><br>
Observacoes:<?php echo e($generos->observacoes); ?><?php /**PATH D:\PSI\Atividade-3\livraria\resources\views/generos/show.blade.php ENDPATH**/ ?>