<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Edicoes;

class EdicoesController extends Controller
{
    //
    public function index(){
    	$edicoes = Edicoes::all();
    	 //   	$autores = Autor::all()->sortbydesc('ida');
    	$edicoes = Edicoes::paginate(4);

    	return view('edicoes.index', [
    	'edicoes' => $edicoes
    	]);
    }

    public function show (Request $request) {
    	$idEdicao = $request->id;
    	$edicoes = Edicoes::findOrFail ($idEdicao);

    	return view ('edicoes.show', [
    		'edicoes' => $edicoes
    	]);
    }
}
